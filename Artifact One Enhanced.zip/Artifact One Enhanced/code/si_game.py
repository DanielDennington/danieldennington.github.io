import pygame, sys
from player import Player
import obstacle
from alien import Alien, Extra
from random import choice, randint
from laser import Laser

# All of the major components of the game
class Game:

    # contains the initializations of all the major sprite groups of the game, along with the audio
    def __init__(self):

        # the screen coordinates to the player sprite    
        player_sprite = Player((screen_width/2, screen_height), screen_width, 5)
        self.player = pygame.sprite.GroupSingle(player_sprite)

        # the amount of player lives, displays the amount as a player image to the top right of the screen
        self.lives = 3
        self.life_display = pygame.image.load('../graphics/player.png').convert_alpha()
        self.live_x_start_pos = screen_width - (self.life_display.get_size()[0] * 2 + 15)

        # the players score, displayed with a locally stored font
        self.score = 0
        self.font = pygame.font.Font('../font/Pixeled.ttf', 20)

        # the screen coordinates to the obstacle sprite, assigns their sizes, and places multiple instances of them  
        self.shape = obstacle.shape
        self.block_size = 6
        self.blocks = pygame.sprite.Group()
        self.obstacle_amount = 4
        self.obstacle_x_position = [num * (screen_width / self.obstacle_amount) for num in range(self.obstacle_amount)]
        self.create_multi_obstacles(*self.obstacle_x_position, x_start = screen_width / 15, y_start = 480)

        # the aliens, their lasers, the extra UFO, the alien amount, as well as their direction
        self.aliens = pygame.sprite.Group()
        self.alien_lasers = pygame.sprite.Group()
        self.extra = pygame.sprite.GroupSingle()
        self.alien_setup(rows = 5, cols = 8)
        self.alien_direction = 1

        # a sprite to the extra UFO, and gives a random spawn time
        self.extra = pygame.sprite.GroupSingle()
        self.extra_spawn_time = randint(400, 800)

        # the BGM, laser sounds, and explosions
        music = pygame.mixer.Sound("../audio/music.wav")
        music.set_volume(0.05)
        music.play(loops = -1)
        self.laser_sound = pygame.mixer.Sound("../audio/laser.wav")
        self.laser_sound.set_volume(0.03)
        self.explosion_sound = pygame.mixer.Sound("../audio/explosion.wav")
        self.explosion_sound.set_volume(0.04)

    # Creates the initial obstacle to use as a base
    def create_obstacle(self, x_start, y_start, offset_x):
        for row_index, row in enumerate(self.shape):
            for col_index, col in enumerate(row):
                if col == 'x':
                     x = x_start + col_index * self.block_size + offset_x
                     y = y_start + row_index * self.block_size
                     block = obstacle.Block(self.block_size, (240, 80, 80), x, y)
                     self.blocks.add(block)

    # Uses the obstacle base to generate multiple obstacles
    def create_multi_obstacles(self, *offset, x_start, y_start):
        for offset_x in offset:
            self.create_obstacle(x_start, y_start, offset_x)

    # Spawns the aliens, gives them initial position and screen offsets   
    def alien_setup(self, rows, cols, x_distance = 60, y_distance = 48, x_offset = 60, y_offset = 100):
        for row_index, row in enumerate(range(rows)):
            for col_index, col in enumerate(range(cols)):
                x = col_index * x_distance + x_offset
                y = row_index * y_distance + y_offset

                if row_index == 0:
                    alien_sprite = Alien('yellow', x, y)
                elif 1 <= row_index <= 2:
                    alien_sprite = Alien('green', x, y)
                else:
                    alien_sprite = Alien('red', x, y)

                self.aliens.add(alien_sprite)

    # Keeps the aliens within the bounds of the window
    def alien_pos_checker(self):
        all_aliens = self.aliens.sprites()
        for alien in all_aliens:
            if alien.rect.right >= screen_width:
                self.alien_direction = -1
                self.alien_move_down(2)
            elif alien.rect.left <= 0:
                self.alien_direction = 1
                self.alien_move_down(2)

    # The speed of the aliens downward movement
    def alien_move_down(self, distance):
        if self.aliens:
            for alien in self.aliens.sprites():
                alien.rect.y += distance

    # Random alien will shoot a laser
    def alien_shoot(self):
        if self.aliens.sprites():
            random_alien = choice(self.aliens.sprites())
            laser_sprite = Laser(random_alien.rect.center, 5, screen_height)
            self.alien_lasers.add(laser_sprite)
            self.laser_sound.play()

    # Spawns a random UFO from either the left or the right of the screen
    def extra_alien_timer(self):
        self.extra_spawn_time -= 1
        if self.extra_spawn_time <= 0:
            self.extra.add(Extra(choice(['right', 'left']), screen_width))
            self.extra_spawn_time = randint(350, 650)

    # Checks for collision of a laser between each major sprite group (not the lives display)
    def collision_checks(self):
        
        # Checks for player's laser collision with obstacles, aliens, and the UFO
        if self.player.sprite.lasers:
            for laser in self.player.sprite.lasers:
                if pygame.sprite.spritecollide(laser, self.blocks, True):
                    laser.kill()

                # Checks which type of enemy is hit and updates the score accordingly for the alien
                alien_hit = pygame.sprite.spritecollide(laser, self.aliens, True)
                if alien_hit:
                    for alien in alien_hit:
                        self.score += alien.value
                    laser.kill()
                    self.explosion_sound.play()

                # Same as above, only for the bonus UFO
                if pygame.sprite.spritecollide(laser, self.extra, True):
                    self.score *= 2
                    laser.kill()

        # The Alien's laser collision with the obstacle and player            
        if self.alien_lasers:
            for laser in self.alien_lasers:
                if pygame.sprite.spritecollide(laser, self.blocks, True):
                    laser.kill()

                if pygame.sprite.spritecollide(laser, self.player, False):
                    laser.kill()
                    self.lives -= 1
                    if self.lives <= 0:
                        pygame.quit()
                        sys.exit()

        # The Alien's body collision with the player and obstacle
        if self.aliens:
            for alien in self.aliens:
                pygame.sprite.spritecollide(alien, self.blocks, True)

                if pygame.sprite.spritecollide(alien, self.player, False):
                    pygame.quit()
                    sys.exit()

    # Displays the lives of the player in the top right of the screeen
    def display_lives(self):
        for life in range(self.lives - 1):
            x = self.live_x_start_pos + (life * (self.life_display.get_size()[0] + 10))
            screen.blit(self.life_display, (x, 8))

    # Displays the player score in the top left of the screen
    def display_score(self):
        score_dis = self.font.render(f"score: {self.score}", False, "white")
        score_rect = score_dis.get_rect(topleft = (10, -10))
        screen.blit(score_dis, score_rect)

    # updates these sprite groups and draws them to the screen
    def run(self):
        
        # Player, alien, and UFO sprite updates
        self.player.update()
        self.alien_lasers.update()
        self.extra.update()

        # Updates and checks on the aliens position, and UFO spawn time
        self.aliens.update(self.alien_direction)
        self.alien_pos_checker()
        self.extra_alien_timer()

        # Checks for collisions for each laser bullet
        self.collision_checks()

        # Draws each sprite onto the screen 
        self.player.sprite.lasers.draw(screen)
        self.player.draw(screen)
        self.blocks.draw(screen)
        self.aliens.draw(screen)
        self.alien_lasers.draw(screen)
        self.extra.draw(screen)
        
        # Displays the lives and score of the player
        self.display_lives()
        self.display_score()

# The CRT-like overlay
class Overlay:
    def __init__(self):
        # Grabs the CRT image from a locally stored file, and displays them according to the screen size
        self.overlay_dis = pygame.image.load("../graphics/tv.png").convert_alpha()
        self.overlay_dis = pygame.transform.scale(self.overlay_dis, (screen_width, screen_height))

    # creates a 'CRT' scanline effect 
    def create_crt_lines(self):
        line_height = 3
        line_amount = int(screen_height / line_height)
        for line in range(line_amount):
            y_pos = line * line_height
            pygame.draw.line(self.overlay_dis, 'black', (0, y_pos), (screen_width, y_pos), 1)
    
    # draws the overlay to the screen
    def draw(self):
        self.overlay_dis.set_alpha(75)
        self.create_crt_lines()
        screen.blit(self.overlay_dis, (0, 0))

# Creates a safeguard against running any unnecessary code included in other imported classes/files 
if __name__ == '__main__':
    
    # initializing the pygame library
    pygame.init()

    # defining the screen width & height size of the screen
    screen_width = 625
    screen_height = 650

    # displaying the screen demensions with a windo
    screen = pygame.display.set_mode((screen_width, screen_height))

    # saving the clock ticks to keep track of them later
    clock = pygame.time.Clock()

    # creating an instance of the 'Game' class
    game = Game()

    # creating the overlay effect
    overlay_dis = Overlay()

    # ensuring alien lasers don't fire more often than 800ms
    ALIENLASER = pygame.USEREVENT + 1
    pygame.time.set_timer(ALIENLASER, 800)

    # creating the main gameplay loop
    while True:
        for event in pygame.event.get():

            # exiting the program only when the player quits the game
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            
            # calling for a random alien to shoot
            if event.type == ALIENLASER:
                game.alien_shoot()

        screen.fill((30, 30, 30))
        game.run()
        overlay_dis.draw()
        
        pygame.display.flip()
        clock.tick(60)